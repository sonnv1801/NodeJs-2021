module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.lopValidation = require('./lop.validation');
module.exports.svValidation = require('./sinhvien.validation');
